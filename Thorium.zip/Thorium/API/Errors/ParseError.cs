﻿namespace Thorium.API.Errors;

public class ParseError : SystemException;