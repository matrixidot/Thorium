﻿namespace Thorium.API.Emit;

using System.Linq.Expressions;
using Tools;

public partial class Emitter {
    private MethodCallExpression HandlePowerOperator(Expression left, Expression right) {
        Type leftType = left.Type;
        Type rightType = right.Type;

        MethodCallExpression powCall;
        if (typeof(int) == leftType && typeof(int) == rightType) {
            powCall = Expression.Call(typeof(IntMath).GetMethod("IPow", [leftType, rightType]), left, right);
        } else if (leftType == typeof(long) && rightType == typeof(long) || leftType == typeof(int) && rightType == typeof(long) || leftType == typeof(long) && rightType == typeof(int)) {
            left = EnsureType(left, typeof(long));
            right = EnsureType(right, typeof(long));
            powCall = Expression.Call(typeof(IntMath).GetMethod("LPow", [leftType, rightType]), left, right);
        }
        else {
            left = EnsureType(left, typeof(double));
            right = EnsureType(right, typeof(double));
            powCall = Expression.Call(typeof(Math).GetMethod("Pow", [typeof(double), typeof(double)]), left, right);
            long a = 2;
            int b = 2;
        }
        return powCall;
    }

    private MethodCallExpression HandleStringConcatenation(Expression left, Expression right) {
        left = EnsureType(left, typeof(object));
        right = EnsureType(right, typeof(object));

        return Expression.Call(typeof(string).GetMethod("Concat", [typeof(object), typeof(object)]), left, right);
    }

    private BinaryExpression HandleLogicalAnd(Expression left, Expression right) {
        left = EnsureBooleanType(left);
        right = EnsureBooleanType(right);
        return Expression.AndAlso(left, right);
    }

    private BinaryExpression HandleLogicalOr(Expression left, Expression right) {
        left = EnsureBooleanType(left);
        right = EnsureBooleanType(right);
        return Expression.OrElse(left, right);
    }

    private BinaryExpression HandleBinaryOperation(ExpressionType expressionType, Expression left, Expression right) {
        // Determine the operand types and promote them if necessary
        Type promotedType = DeterminePromotedType(left.Type, right.Type, expressionType);

        left = EnsureType(left, promotedType);
        right = EnsureType(right, promotedType);

        return Expression.MakeBinary(expressionType, left, right);
    }
}