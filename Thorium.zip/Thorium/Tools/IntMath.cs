﻿namespace Thorium.Tools;

public class IntMath {
    public static int IPow(int a, int b) {
        return (int)Math.Pow(a, b);
    }
    public static long LPow(long a, long b) {
        return (long)Math.Pow(a, b);
    }
}